Note: the model.* files were created using Papyrus UML tool. The contents have been copied to use_case_model.png.

Team Members - Group 5:
Sorcha Bayle - 16136012
John Frazer - x16138015
Carl Leslie – 16137655
